<html>
	<head>
		<title>COMP4039 - Sample code</title>
		<link rel="stylesheet" href="css/mvp.css">
	</head>
	<body>	
		<main>
			<h1>Basic features of the language</h1>
			<ul>
				<li>
					<a href="php-demos/index.php">PHP demos</a>
				</li>
				<li>
					<a href="lab-8-demo-code/index.php">Lab 8 demo code</a>
				</li>
				<li>
					<a href="js-demos/index.html">Javascript demos</a>
				</li>
				<li>
					<a href="exercise7/new.html">Exercise 7 Website Copy</a>
				</li>
				<li>
					<a href="exercise8/index.php">Exercise 8</a>
				</li>
				<li>
					<a href="coursework2/login.php">Coursework 2</a>
				</li>
			</ul>
			<hr/>
			<?php phpinfo();?>
		</main>
	</body>
</html>